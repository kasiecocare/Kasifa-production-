import { useState } from 'react';
import { api } from '../lib/api';

export default function DevLogin() {
  const [email, setEmail] = useState('user@example.com');
  const [role, setRole] = useState<'INVESTOR'|'SELLER'|'ADMIN'>('INVESTOR');
  const [token, setToken] = useState<string>('');

  async function login() {
    const res = await api('/auth/dev-login', { method: 'POST', body: JSON.stringify({ email, role }) });
    if (res.ok) {
      const t = res.data.access_token;
      setToken(t);
      localStorage.setItem('kasifa_token', t);
      localStorage.setItem('kasifa_role', role);
    } else {
      alert(JSON.stringify(res.data));
    }
  }

  return (
    <div style={{ padding: 24 }}>
      <h1>Dev Login</h1>
      <input value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="email" />
      <select value={role} onChange={(e)=>setRole(e.target.value as any)}>
        <option>INVESTOR</option>
        <option>SELLER</option>
        <option>ADMIN</option>
      </select>
      <button onClick={login}>Login</button>
      {token && <pre style={{ whiteSpace: 'pre-wrap' }}>{token}</pre>}
    </div>
  );
}
