import Link from 'next/link';

export default function Home() {
  return (
    <div style={{ padding: 24, fontFamily: 'system-ui' }}>
      <h1>Kasifa v5</h1>
      <p>Pick a portal:</p>
      <ul>
        <li><Link href="/investor">Investor Dashboard</Link></li>
        <li><Link href="/seller">Seller Dashboard</Link></li>
        <li><Link href="/admin">Admin Dashboard</Link></li>
        <li><Link href="/marketplace/guest">Marketplace (Guest)</Link></li>
        <li><Link href="/marketplace/investor">Marketplace (Investor)</Link></li>
        <li><Link href="/marketplace/3d">Marketplace (3D view)</Link></li>
      </ul>
    </div>
  );
}
