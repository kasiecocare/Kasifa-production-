import Link from 'next/link';

export default function Page() {
  return (
    <div style={ padding: 24, fontFamily: 'system-ui' }>
      <h1>Investor Dashboard</h1>
      <p>Investor cannot access Seller portal. Use Investor Marketplace for discounted view.</p>
      <p><Link href="/dev-login">Dev Login</Link></p>
      <p><Link href="/">Home</Link></p>
    </div>
  );
}
