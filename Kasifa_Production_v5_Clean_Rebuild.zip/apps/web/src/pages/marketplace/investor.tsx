import { useEffect, useState } from 'react';
import Link from 'next/link';
import { api, API_BASE } from '../../lib/api';

function token() {
  if (typeof window === 'undefined') return '';
  return localStorage.getItem('kasifa_token') || '';
}

export default function InvestorMarketplace() {
  const [products, setProducts] = useState<any[]>([]);
  const [msg, setMsg] = useState<string>('');
  useEffect(() => { api('/marketplace/products').then(r => r.ok && setProducts(r.data)); }, []);

  async function checkout(productId: string) {
    setMsg('');
    const res = await fetch(`${API_BASE}/marketplace/investor/checkout`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'authorization': `Bearer ${token()}` },
      body: JSON.stringify({ product_id: productId, mode: 'INVESTOR', external_topup_minor: 0 }),
    });
    const t = await res.text();
    setMsg(t);
  }

  return (
    <div style={{ padding: 24 }}>
      <h1>Marketplace (Investor Mode)</h1>
      <p>Investor sees Kasifa discounted view (subsidy capped). Locked wallet used first; if 0, must use Guest mode.</p>
      <p><Link href="/dev-login">Dev Login</Link> • <Link href="/marketplace/guest">Guest Mode</Link> • <Link href="/">Home</Link></p>
      <ul>
        {products.map(p => (
          <li key={p.id}>
            {p.title} — base {p.basePriceMinor}
            <button style={{ marginLeft: 8 }} onClick={() => checkout(p.id)}>Checkout (Investor)</button>
          </li>
        ))}
      </ul>
      {msg && <pre style={{ whiteSpace: 'pre-wrap' }}>{msg}</pre>}
    </div>
  );
}
