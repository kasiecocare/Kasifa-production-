import { useEffect, useState } from 'react';
import Link from 'next/link';
import { api } from '../../lib/api';

export default function GuestMarketplace() {
  const [products, setProducts] = useState<any[]>([]);
  useEffect(() => { api('/marketplace/products').then(r => r.ok && setProducts(r.data)); }, []);
  return (
    <div style={{ padding: 24 }}>
      <h1>Marketplace (Guest Mode)</h1>
      <p>Guest sees seller promo price, no Kasifa subsidy.</p>
      <p><Link href="/">Home</Link></p>
      <ul>
        {products.map(p => (
          <li key={p.id}>
            {p.title} — base {p.basePriceMinor} — seller promo {p.guestPromoDiscountMinor}
          </li>
        ))}
      </ul>
    </div>
  );
}
