import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import Link from 'next/link';

export default function World3D() {
  return (
    <div style={{ height: '100vh' }}>
      <div style={{ position: 'absolute', zIndex: 10, padding: 12 }}>
        <Link href="/">Home</Link>
        <div>3D view placeholder (camera 자유 movement via OrbitControls)</div>
      </div>
      <Canvas camera={{ position: [5, 5, 5] }}>
        <ambientLight />
        <directionalLight position={[10, 10, 10]} />
        <mesh>
          <boxGeometry args={[2, 2, 2]} />
          <meshStandardMaterial />
        </mesh>
        <OrbitControls />
      </Canvas>
    </div>
  );
}
