import Link from 'next/link';

export default function Page() {
  return (
    <div style={ padding: 24, fontFamily: 'system-ui' }>
      <h1>Admin Dashboard</h1>
      <p>Admin can open risk cases and export immutable audit logs.</p>
      <p><Link href="/dev-login">Dev Login</Link></p>
      <p><Link href="/">Home</Link></p>
    </div>
  );
}
