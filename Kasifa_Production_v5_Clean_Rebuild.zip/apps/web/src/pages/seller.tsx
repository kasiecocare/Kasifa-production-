import Link from 'next/link';

export default function Page() {
  return (
    <div style={ padding: 24, fontFamily: 'system-ui' }>
      <h1>Seller Dashboard</h1>
      <p>Seller cannot access Investor portal. Use pickup-code verifier to release escrow.</p>
      <p><Link href="/dev-login">Dev Login</Link></p>
      <p><Link href="/">Home</Link></p>
    </div>
  );
}
