import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_GUARD } from '@nestjs/core';
import { ScheduleModule } from '@nestjs/schedule';
import { ThrottlerGuard } from '@nestjs/throttler';
import { AuthModule } from './modules/auth/auth.module';
import { HardeningModule } from './modules/hardening/hardening.module';
import { AuditModule } from './modules/audit/audit.module';
import { LedgerModule } from './modules/ledger/ledger.module';
import { PaymentsWebhooksModule } from './modules/payments_webhooks/payments_webhooks.module';
import { MarketplaceModule } from './modules/marketplace/marketplace.module';
import { SellerModule } from './modules/seller/seller.module';
import { ComplianceModule } from './modules/compliance/compliance.module';
import { RolesGuard } from './common/roles.guard';
import { JwtAuthGuard } from './modules/auth/jwt_auth.guard';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ScheduleModule.forRoot(),
    HardeningModule,

    AuthModule,
    AuditModule,
    LedgerModule,
    PaymentsWebhooksModule,
    MarketplaceModule,
    SellerModule,
    ComplianceModule,
  ],
  providers: [
    { provide: APP_GUARD, useClass: ThrottlerGuard },
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    { provide: APP_GUARD, useClass: RolesGuard },
  ],
})
export class AppModule {}
