import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import helmet from 'helmet';
import { AppModule } from './app.module';
import { ConfigService } from '@nestjs/config';
import pinoHttp from 'pino-http';
import { nanoid } from 'nanoid';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { bufferLogs: true });

  app.use(helmet());
  app.use(
    pinoHttp({
      genReqId: (req) => (req.headers['x-request-id'] as string) || nanoid(),
    }),
  );

  const config = app.get(ConfigService);
  const port = Number(config.get('PORT') ?? 3001);

  await app.listen(port, '0.0.0.0');
}
bootstrap();
