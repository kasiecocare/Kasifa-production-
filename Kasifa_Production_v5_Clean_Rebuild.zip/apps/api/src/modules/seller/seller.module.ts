import { Module } from '@nestjs/common';
import { SellerController } from './seller.controller';
import { SellerService } from './seller.service';
import { PrismaService } from '../../prisma.service';
import { LedgerModule } from '../ledger/ledger.module';
import { AuditModule } from '../audit/audit.module';

@Module({
  imports: [LedgerModule, AuditModule],
  controllers: [SellerController],
  providers: [SellerService, PrismaService],
})
export class SellerModule {}
