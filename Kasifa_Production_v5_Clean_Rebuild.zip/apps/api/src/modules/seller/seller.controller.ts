import { Body, Controller, Post, Req } from '@nestjs/common';
import { z } from 'zod';
import { Roles } from '../../common/roles.decorator';
import { SellerService } from './seller.service';

const VerifySchema = z.object({
  order_id: z.string().uuid(),
  pickup_code: z.string().min(6).max(6),
  device_gps_lat: z.number(),
  device_gps_lng: z.number(),
});

@Controller('/seller')
export class SellerController {
  constructor(private svc: SellerService) {}

  @Roles('SELLER')
  @Post('/verify-pickup')
  async verify(@Req() req: any, @Body() body: unknown) {
    const dto = VerifySchema.parse(body);
    return this.svc.verifyPickup(req.user.userId, dto);
  }
}
