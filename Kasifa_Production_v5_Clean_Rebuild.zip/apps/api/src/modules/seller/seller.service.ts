import { Injectable, BadRequestException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../../prisma.service';
import { LedgerService } from '../ledger/ledger.service';
import { AuditService } from '../audit/audit.service';
import crypto from 'crypto';

function haversineMeters(aLat: number, aLng: number, bLat: number, bLng: number): number {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(bLat - aLat);
  const dLng = toRad(bLng - aLng);
  const s1 = Math.sin(dLat/2)**2 + Math.cos(toRad(aLat))*Math.cos(toRad(bLat))*Math.sin(dLng/2)**2;
  return 2 * R * Math.asin(Math.sqrt(s1));
}

@Injectable()
export class SellerService {
  constructor(private prisma: PrismaService, private ledger: LedgerService, private audit: AuditService) {}

  async verifyPickup(sellerUserId: string, dto: { order_id: string; pickup_code: string; device_gps_lat: number; device_gps_lng: number }) {
    const order = await this.prisma.order.findUnique({ where: { id: dto.order_id } });
    if (!order) throw new BadRequestException('order not found');
    if (order.sellerUserId !== sellerUserId) throw new ForbiddenException('not your order');
    if (order.status !== 'PAID_ESCROW_HELD') throw new BadRequestException('order not in escrow-held state');

    const sellerProfile = await this.prisma.sellerProfile.findUnique({ where: { userId: sellerUserId } });
    if (!sellerProfile) throw new BadRequestException('seller profile missing');

    // GPS proximity enforcement
    const dist = haversineMeters(dto.device_gps_lat, dto.device_gps_lng, sellerProfile.storeGpsLat, sellerProfile.storeGpsLng);
    if (dist > 250) throw new ForbiddenException('device location not near store GPS');

    const hash = crypto.createHash('sha256').update(dto.pickup_code).digest('hex');
    if (hash !== order.pickupCodeHash) throw new ForbiddenException('invalid pickup code');

    // Release escrow into seller withdrawable
    const escrow = await this.ledger.ensureWallet(sellerUserId, 'ESCROW_HELD');
    const withdraw = await this.ledger.ensureWallet(sellerUserId, 'WITHDRAWABLE');

    await this.ledger.post({
      idempotencyKey: `escrow_release:${order.id}`,
      debitWalletId: escrow.id,
      creditWalletId: withdraw.id,
      amountMinor: BigInt(order.escrowTargetMinor),
      memo: `ESCROW_RELEASE:${order.id}`,
    });

    const updated = await this.prisma.order.update({ where: { id: order.id }, data: { status: 'PICKUP_VERIFIED' } });
    await this.audit.append(sellerUserId, 'PICKUP_VERIFIED', 'Order', order.id, { dist_m: dist });

    return { ok: true, order: updated };
  }
}
