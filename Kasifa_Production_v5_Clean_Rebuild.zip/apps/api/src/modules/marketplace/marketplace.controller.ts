import { Body, Controller, Get, Post, Req } from '@nestjs/common';
import { z } from 'zod';
import { MarketplaceService } from './marketplace.service';
import { Roles } from '../../common/roles.decorator';

const CreateProductSchema = z.object({
  title: z.string().min(2),
  base_price_minor: z.number().int().positive(),
  guest_promo_discount_minor: z.number().int().nonnegative().default(0),
});

const CheckoutSchema = z.object({
  product_id: z.string().uuid(),
  mode: z.enum(['INVESTOR', 'GUEST']),
  // investor mode: optional top-up from external when locked not enough (rules enforced)
  external_topup_minor: z.number().int().nonnegative().optional(),
});

@Controller('/marketplace')
export class MarketplaceController {
  constructor(private svc: MarketplaceService) {}

  @Roles('SELLER')
  @Post('/seller/products')
  async createProduct(@Req() req: any, @Body() body: unknown) {
    const dto = CreateProductSchema.parse(body);
    return this.svc.createProduct(req.user.userId, dto);
  }

  @Get('/products')
  async list() {
    return this.svc.listProducts();
  }

  @Roles('INVESTOR')
  @Post('/investor/checkout')
  async investorCheckout(@Req() req: any, @Body() body: unknown) {
    const dto = CheckoutSchema.parse(body);
    return this.svc.checkout(req.user.userId, dto.product_id, 'INVESTOR', dto.external_topup_minor ?? 0);
  }

  @Post('/guest/checkout')
  async guestCheckout(@Body() body: unknown) {
    const dto = CheckoutSchema.parse(body);
    return this.svc.checkout(null, dto.product_id, 'GUEST', dto.external_topup_minor ?? 0);
  }
}
