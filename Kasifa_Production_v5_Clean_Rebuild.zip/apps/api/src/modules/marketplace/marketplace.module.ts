import { Module } from '@nestjs/common';
import { MarketplaceController } from './marketplace.controller';
import { MarketplaceService } from './marketplace.service';
import { PrismaService } from '../../prisma.service';
import { LedgerModule } from '../ledger/ledger.module';
import { AuditModule } from '../audit/audit.module';
import { ConfigModule } from '@nestjs/config';

@Module({
  imports: [LedgerModule, AuditModule, ConfigModule],
  controllers: [MarketplaceController],
  providers: [MarketplaceService, PrismaService],
})
export class MarketplaceModule {}
