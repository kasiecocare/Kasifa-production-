import { Injectable, BadRequestException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../../prisma.service';
import { LedgerService } from '../ledger/ledger.service';
import { AuditService } from '../audit/audit.service';
import { ConfigService } from '@nestjs/config';
import crypto from 'crypto';

type Mode = 'INVESTOR' | 'GUEST';

@Injectable()
export class MarketplaceService {
  constructor(
    private prisma: PrismaService,
    private ledger: LedgerService,
    private audit: AuditService,
    private cfg: ConfigService,
  ) {}

  async createProduct(sellerUserId: string, dto: { title: string; base_price_minor: number; guest_promo_discount_minor: number }) {
    const product = await this.prisma.product.create({
      data: {
        sellerUserId,
        title: dto.title,
        basePriceMinor: dto.base_price_minor,
        guestPromoDiscountMinor: dto.guest_promo_discount_minor,
      },
    });
    await this.audit.append(sellerUserId, 'PRODUCT_CREATED', 'Product', product.id, dto);
    return product;
  }

  async listProducts() {
    return this.prisma.product.findMany({ orderBy: { createdAt: 'desc' } });
  }

  // Pricing rules:
  // - base_price = seller-set
  // - guest promo discount is seller-funded, applies only in GUEST mode
  // - investor discount is Kasifa-funded; escrow target remains base_price; subsidy tops up difference (capped)
  async checkout(buyerUserId: string | null, productId: string, mode: Mode, externalTopupMinor: number) {
    const product = await this.prisma.product.findUnique({ where: { id: productId } });
    if (!product) throw new BadRequestException('product not found');

    const base = product.basePriceMinor;
    const guestPromo = product.guestPromoDiscountMinor;

    // Determine investor discount percent by tier (simple placeholder mapping)
    // Actual tiering should be stored in InvestorProfile.tier and mapped in config table; kept deterministic here.
    let investorDiscountPct = 0;
    if (mode === 'INVESTOR') {
      if (!buyerUserId) throw new BadRequestException('buyer required');
      const investor = await this.prisma.investorProfile.findUnique({ where: { userId: buyerUserId } });
      if (!investor) throw new ForbiddenException('not an investor');
      // Example: Bronze 1.. -> 10%, Gold -> 20%, Diamond -> 30%
      const tier = investor.tier.toLowerCase();
      investorDiscountPct = tier.includes('diamond') ? 30 : tier.includes('gold') ? 20 : tier.includes('bronx') || tier.includes('bronze') ? 10 : 10;
    }

    if (mode === 'GUEST') {
      const escrowTarget = Math.max(0, base - guestPromo);
      const buyerPays = escrowTarget;
      const subsidyPays = 0;
      return this.createOrderAndHoldEscrow({
        buyerUserId,
        mode,
        productId,
        base,
        escrowTarget,
        buyerPays,
        subsidyPays,
        externalTopupMinor,
      });
    }

    // Investor mode:
    const capPct = Number(this.cfg.get('SUBSIDY_MAX_PCT_PER_ORDER') ?? 50);
    const rawDiscount = Math.floor((base * investorDiscountPct) / 100);
    const maxDiscount = Math.floor((base * capPct) / 100);
    const platformDiscount = Math.min(rawDiscount, maxDiscount);

    const buyerPays = base - platformDiscount; // investor pays discounted
    const escrowTarget = base; // escrow target always base_price
    const subsidyPays = escrowTarget - buyerPays;

    // Enforce locked wallet rules:
    // - If buyer is investor mode, locked wallet must be used first
    // - If locked wallet is zero => cannot pay via investor mode (must use guest mode)
    const locked = await this.ledger.ensureWallet(buyerUserId!, 'LOCKED_MARKET');
    const lockedBalance = locked.balanceMinor;

    if (lockedBalance === 0n) {
      throw new ForbiddenException('Investor locked wallet is zero; use Guest checkout');
    }

    // Use locked first then external topup if needed
    const buyerPaysBig = BigInt(buyerPays);
    const useLocked = lockedBalance >= buyerPaysBig ? buyerPaysBig : lockedBalance;
    const remaining = buyerPaysBig - useLocked;
    const extTopup = BigInt(externalTopupMinor);

    if (remaining > 0n) {
      if (extTopup < remaining) throw new BadRequestException('external topup insufficient');
      // external topup is conceptual; in real system this must be webhook-confirmed before checkout finalization.
    }

    return this.createOrderAndHoldEscrow({
      buyerUserId,
      mode,
      productId,
      base,
      escrowTarget,
      buyerPays,
      subsidyPays,
      externalTopupMinor,
      lockedSpendMinor: Number(useLocked),
    });
  }

  private async createOrderAndHoldEscrow(params: {
    buyerUserId: string | null;
    mode: Mode;
    productId: string;
    base: number;
    escrowTarget: number;
    buyerPays: number;
    subsidyPays: number;
    externalTopupMinor: number;
    lockedSpendMinor?: number;
  }) {
    // Ensure wallets
    const seller = await this.prisma.product.findUnique({ where: { id: params.productId } }).then(p => p!.sellerUserId);
    const escrow = await this.ledger.ensureWallet(seller, 'ESCROW_HELD');
    const subsidy = await this.ledger.ensureWallet('SYSTEM', 'SUBSIDY_POOL'); // SYSTEM user must exist; created at bootstrap in real impl

    // Create pickup code hash (seller verification uses hash compare)
    const pickupCode = crypto.randomInt(100000, 999999).toString();
    const pickupHash = crypto.createHash('sha256').update(pickupCode).digest('hex');

    const order = await this.prisma.order.create({
      data: {
        sellerUserId: seller,
        buyerUserId: params.buyerUserId,
        mode: params.mode,
        productId: params.productId,
        basePriceMinor: params.base,
        buyerPayMinor: params.buyerPays,
        subsidyPayMinor: params.subsidyPays,
        escrowTargetMinor: params.escrowTarget,
        status: 'PAID_ESCROW_HELD',
        pickupCodeHash: pickupHash,
      },
    });

    // Move funds (conceptual):
    // - Buyer payments: locked spend posted out of buyer locked wallet into seller escrow
    // - Subsidy top-up: from subsidy pool to seller escrow
    // This implementation posts only ledger entries; assumes balances exist.
    const memo = `ORDER_ESCROW_HOLD:${order.id}`;
    if (params.mode === 'INVESTOR' && params.buyerUserId && params.lockedSpendMinor && params.lockedSpendMinor > 0) {
      const buyerLocked = await this.ledger.ensureWallet(params.buyerUserId, 'LOCKED_MARKET');
      await this.ledger.post({
        idempotencyKey: `locked:${order.id}`,
        debitWalletId: buyerLocked.id,
        creditWalletId: escrow.id,
        amountMinor: BigInt(params.lockedSpendMinor),
        memo,
      });
    }

    if (params.subsidyPays > 0) {
      // In production, subsidy pool must be funded; here we allow posting if funds exist
      await this.ledger.post({
        idempotencyKey: `subsidy:${order.id}`,
        debitWalletId: subsidy.id,
        creditWalletId: escrow.id,
        amountMinor: BigInt(params.subsidyPays),
        memo,
      });
    }

    await this.audit.append(params.buyerUserId, 'ORDER_CREATED', 'Order', order.id, {
      mode: params.mode,
      productId: params.productId,
      buyerPays: params.buyerPays,
      subsidyPays: params.subsidyPays,
      escrowTarget: params.escrowTarget,
    });

    return { order, pickup_code_for_demo_only: pickupCode };
  }
}
