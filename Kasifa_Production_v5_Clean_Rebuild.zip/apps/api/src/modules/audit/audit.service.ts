import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma.service';
import crypto from 'crypto';

@Injectable()
export class AuditService {
  constructor(private prisma: PrismaService) {}

  async append(actorUserId: string | null, action: string, entityType: string, entityId: string | null, meta: any) {
    const last = await this.prisma.auditLog.findFirst({ orderBy: { createdAt: 'desc' } });
    const chainPrev = last?.chainHash ?? null;
    const metaJson = JSON.stringify(meta ?? {});
    const hash = crypto.createHash('sha256').update(`${chainPrev ?? ''}|${actorUserId ?? ''}|${action}|${entityType}|${entityId ?? ''}|${metaJson}`).digest('hex');

    return this.prisma.auditLog.create({
      data: {
        chainPrev,
        chainHash: hash,
        actorUserId,
        action,
        entityType,
        entityId,
        metaJson,
      },
    });
  }
}
