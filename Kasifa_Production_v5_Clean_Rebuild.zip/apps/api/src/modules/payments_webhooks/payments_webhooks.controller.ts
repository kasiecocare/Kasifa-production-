import { Body, Controller, Headers, Post } from '@nestjs/common';
import { z } from 'zod';
import { PaymentsWebhooksService } from './payments_webhooks.service';

const EventSchema = z.object({
  provider: z.string(),
  reference: z.string(),
  amount_minor: z.number().int().nonnegative(),
});

@Controller('/webhooks')
export class PaymentsWebhooksController {
  constructor(private svc: PaymentsWebhooksService) {}

  // Webhook-only ingestion: never trust client-initiated credits.
  @Post('/payments')
  async ingest(@Body() body: unknown, @Headers('x-request-id') rid?: string) {
    const event = EventSchema.parse(body);
    return this.svc.ingest(event.provider, event.reference, event.amount_minor, rid ?? null);
  }
}
