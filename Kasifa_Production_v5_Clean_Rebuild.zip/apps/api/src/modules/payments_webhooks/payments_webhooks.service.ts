import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma.service';
import { AuditService } from '../audit/audit.service';

@Injectable()
export class PaymentsWebhooksService {
  constructor(private prisma: PrismaService, private audit: AuditService) {}

  async ingest(provider: string, reference: string, amountMinor: number, requestId: string | null) {
    const uniqueKey = `${provider}:${reference}`;
    const created = await this.prisma.paymentWebhookEvent.upsert({
      where: { uniqueKey },
      update: {},
      create: { provider, reference, amountMinor, uniqueKey },
    });

    // Mark as processed (idempotent) - actual crediting into wallet buckets would be in reconciler module
    if (!created.processedAt) {
      await this.prisma.paymentWebhookEvent.update({ where: { id: created.id }, data: { processedAt: new Date() } });
      await this.audit.append(null, 'WEBHOOK_INGESTED', 'PaymentWebhookEvent', created.id, { requestId, provider, reference, amountMinor });
    }

    return { ok: true, id: created.id };
  }
}
