import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma.service';
import { AuditService } from '../audit/audit.service';

@Injectable()
export class ComplianceService {
  constructor(private prisma: PrismaService, private audit: AuditService) {}

  async createCase(actor: string, entityType: string, entityId: string, reason: string | null) {
    const c = await this.prisma.riskCase.create({ data: { entityType, entityId, status: 'FLAGGED', reason } });
    await this.audit.append(actor, 'RISK_CASE_CREATED', 'RiskCase', c.id, { entityType, entityId, reason });
    return c;
  }

  async exportAudit() {
    const rows = await this.prisma.auditLog.findMany({ orderBy: { createdAt: 'asc' }, take: 1000 });
    return { count: rows.length, rows };
  }
}
