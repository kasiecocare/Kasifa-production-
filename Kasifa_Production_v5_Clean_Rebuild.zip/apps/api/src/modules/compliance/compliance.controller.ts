import { Controller, Get, Post, Body, Req } from '@nestjs/common';
import { Roles } from '../../common/roles.decorator';
import { z } from 'zod';
import { ComplianceService } from './compliance.service';

const CaseSchema = z.object({
  entity_type: z.string(),
  entity_id: z.string(),
  reason: z.string().optional(),
});

@Controller('/compliance')
export class ComplianceController {
  constructor(private svc: ComplianceService) {}

  @Roles('ADMIN')
  @Post('/cases')
  async create(@Req() req: any, @Body() body: unknown) {
    const dto = CaseSchema.parse(body);
    return this.svc.createCase(req.user.userId, dto.entity_type, dto.entity_id, dto.reason ?? null);
  }

  @Roles('ADMIN')
  @Get('/audit/export')
  async export() {
    return this.svc.exportAudit();
  }
}
