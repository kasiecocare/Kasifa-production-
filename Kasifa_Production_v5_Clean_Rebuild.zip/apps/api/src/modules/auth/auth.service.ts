import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../../prisma.service';
import { Role } from '@kasifa/shared';

@Injectable()
export class AuthService {
  constructor(private jwt: JwtService, private prisma: PrismaService) {}

  async devLogin(email: string, role: Role) {
    const user = await this.prisma.user.upsert({
      where: { email },
      update: { role },
      create: { email, role },
    });
    const token = await this.jwt.signAsync({ sub: user.id, role: user.role, email: user.email });
    return { access_token: token, user };
  }
}
