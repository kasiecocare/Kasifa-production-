import { Body, Controller, Post } from '@nestjs/common';
import { z } from 'zod';
import { AuthService } from './auth.service';

const LoginSchema = z.object({
  email: z.string().email(),
  role: z.enum(['INVESTOR', 'SELLER', 'ADMIN']),
});

@Controller('/auth')
export class AuthController {
  constructor(private auth: AuthService) {}

  @Post('/dev-login')
  async devLogin(@Body() body: unknown) {
    const { email, role } = LoginSchema.parse(body);
    return this.auth.devLogin(email, role);
  }
}
