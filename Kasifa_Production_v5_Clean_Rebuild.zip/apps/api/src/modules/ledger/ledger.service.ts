import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../prisma.service';

@Injectable()
export class LedgerService {
  constructor(private prisma: PrismaService) {}

  async ensureWallet(userId: string, kind: string) {
    return this.prisma.wallet.upsert({
      where: { userId_kind: { userId, kind } },
      update: {},
      create: { userId, kind, balanceMinor: 0 },
    });
  }

  async post(params: {
    idempotencyKey: string;
    debitWalletId?: string | null;
    creditWalletId?: string | null;
    amountMinor: bigint;
    memo: string;
  }) {
    if (params.amountMinor <= 0n) throw new BadRequestException('amount must be > 0');
    return this.prisma.$transaction(async (tx) => {
      const existing = await tx.ledgerEntry.findUnique({ where: { idempotencyKey: params.idempotencyKey } });
      if (existing) return existing;

      if (params.debitWalletId) {
        const w = await tx.wallet.findUnique({ where: { id: params.debitWalletId } });
        if (!w) throw new BadRequestException('debit wallet missing');
        if (w.balanceMinor < params.amountMinor) throw new BadRequestException('insufficient funds');
        await tx.wallet.update({ where: { id: w.id }, data: { balanceMinor: w.balanceMinor - params.amountMinor } });
      }
      if (params.creditWalletId) {
        const w = await tx.wallet.findUnique({ where: { id: params.creditWalletId } });
        if (!w) throw new BadRequestException('credit wallet missing');
        await tx.wallet.update({ where: { id: w.id }, data: { balanceMinor: w.balanceMinor + params.amountMinor } });
      }

      return tx.ledgerEntry.create({
        data: {
          idempotencyKey: params.idempotencyKey,
          debitWalletId: params.debitWalletId ?? null,
          creditWalletId: params.creditWalletId ?? null,
          amountMinor: params.amountMinor,
          memo: params.memo,
        },
      });
    });
  }
}
