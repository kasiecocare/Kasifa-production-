-- 001_init.sql (generated manually)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Prisma will manage tables via migrate; this file is a placeholder for raw-SQL environments.
