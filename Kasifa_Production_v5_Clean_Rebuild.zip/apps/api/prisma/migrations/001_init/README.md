Prisma migrate will generate migration.sql here after `prisma migrate dev`.
