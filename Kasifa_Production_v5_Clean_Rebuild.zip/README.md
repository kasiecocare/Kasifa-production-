# Kasifa Production v5 (Clean, Wired, Deployable)

This is a clean rebuild with:
- NestJS API (RBAC, immutable audit, wallets+ledger, marketplace pricing+checkout, webhook-only PSP ingestion, recon locks, refunds worker, risk cases)
- Next.js Web (Investor/Seller/Admin dashboards + marketplace mode separation + minimal 3D view)
- Postgres + Redis via Docker

## Quick start (Codespaces)
1) `npm install`
2) `npm run db:up`
3) `cp apps/api/.env.example apps/api/.env`
4) `cd apps/api && npx prisma migrate dev && npx prisma generate`
5) In root: `npm run dev` (or run api+web separately)

Ports:
- Web: 3000
- API: 3001
