export type Role = "INVESTOR" | "SELLER" | "ADMIN";

export type Currency = "GHS";

export type MarketplaceMode = "INVESTOR" | "GUEST" | "SELLER_BROWSE";

export const ROLES: Role[] = ["INVESTOR", "SELLER", "ADMIN"];
